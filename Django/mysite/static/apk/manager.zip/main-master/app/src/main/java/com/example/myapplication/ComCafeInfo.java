package com.example.myapplication;

import com.google.gson.annotations.SerializedName;

import java.sql.Time;
import java.time.LocalTime;

public class ComCafeInfo {
    @SerializedName("id")
    int id;
    //카페이름
    String cafe_name;
    //사용자이름
    String user_name;
    //위치정보
    @SerializedName("x")
    float positionX;
    @SerializedName("y")
    float positionY;
    //영업시간
    String start_time;
    String end_time;
    //금일 영업 시간
    String start_today;
    String end_today;
    //전화번호
    @SerializedName("phone")
    String call_num;
    //email
    @SerializedName("com_num")
    String email;
    //전체 좌석 수
    @SerializedName("seat_total")
    int seat_total;
    //현재 좌석 수
    @SerializedName("seat_curr")
    int seat_curr;
    //카페 소개
    @SerializedName("notice")
    String cafe_intro;
    //현재 영업 상태
    @SerializedName("business")
    boolean op_cl;

    @SerializedName("star")
    float star;

    @SerializedName("event")
    String event;

    public void getInfo(String cafe_name, float x, float y, String start_time,String end_time,String call_num,String email,String notice, float star,String com_num,boolean business,int seat_total){
        this.cafe_name = cafe_name;
        this.positionX = x;
        this.positionY = y;
        this.start_time = start_time;
        this.end_time = end_time;
        this.call_num = call_num;
        this.cafe_intro = notice;
        this.star = star;
        this.email = com_num;
        this.op_cl = business;
        this.seat_total = seat_total;
    }
}
