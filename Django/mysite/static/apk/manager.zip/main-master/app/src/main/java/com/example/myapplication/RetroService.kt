/*
package com.example.myapplication

import retrofit2.Call
import retrofit2.http.*

interface  RetroService{
    @FormUrlEncoded
    @POST("/app_login/")
    fun requestLogin(
        @Field("userid") userid:String,
        @Field("userpw") userpw:String
    ) : Call<Login>

    @GET("/cafe")


    @FormUrlEncoded
    @POST("/user/")
    fun requestUser(
            @Field("name") name:String,
            @Field("email") email:String,
            @Field("sex") sex:String,
            @Field("phone") phone:String,
            @Field("birthday") birthday:String
    ): Call<User>

    @FormUrlEncoded
    @POST("/cafe")
    fun requestCafe(
           // @Field("no")
    )
}

*/