package com.example.myapplication;

public class Review {
    String uid;
    String review;


}
