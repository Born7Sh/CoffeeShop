package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class UserInformation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_information);

        Intent intent = getIntent();

        final CafeInfo ci = (CafeInfo)intent.getSerializableExtra("CafeInfo");


        // 카페명은 CafeName
        final EditText CafeName = (EditText) findViewById(R.id.CafeName);
        CafeName.setText(ci.cafe_name);
        // 이름은 Name
        EditText Name = (EditText) findViewById(R.id.Name);
        // 영업시작/종료는 StartTime/CloseTime
        final EditText StartTime = (EditText)findViewById(R.id.StartTime);
        StartTime.setText(ci.start_time);
        final EditText CloseTime = (EditText)findViewById(R.id.CloseTime);
        CloseTime.setText(ci.end_time);
        // 비밀번호/비밀번호 체크는 Password/PasswordCheck
        EditText Password = (EditText)findViewById(R.id.Password);
        // 전화번호는 PhoneNumber
        final EditText PhoneNumber = (EditText)findViewById(R.id.PhoneNumber);
        PhoneNumber.setText(ci.call_num);
        // 이메일은 Email
        final EditText Email = (EditText)findViewById(R.id.Email);
        Email.setText(ci.email);
        // 변경 버튼은 Change1
        Button Change1 = (Button)findViewById(R.id.Change1);
        Change1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             //   ci.cafe_name = String.valueOf(CafeName.getText());
                ci.start_time = String.valueOf(StartTime.getText());
                ci.end_time = String.valueOf(CloseTime.getText());
                ci.call_num = String.valueOf(PhoneNumber.getText());
                ci.changeInfo();
                ci.getCafeInfo(ci);
                Intent intent = new Intent(v.getContext(),UserInformation.class);
                intent.putExtra("CafeInfo",ci);
                finish();
                startActivity(intent);

            }
        });

        // 좌석 수는 Seat
        EditText Seat = (EditText)findViewById(R.id.Seat);
        // 카페좌석관리 Change2
        Button Change2 = (Button) findViewById(R.id.Change2);

        Change2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (v.getContext(), CafeSeatControl.class);
                startActivity(intent);
            }
        });

    }
}
