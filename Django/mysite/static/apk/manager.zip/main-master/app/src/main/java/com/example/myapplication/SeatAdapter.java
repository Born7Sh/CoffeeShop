package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class SeatAdapter extends RecyclerView.Adapter<SeatAdapter.ItemViewHolder>{
    private ArrayList<SeatData> listSeatData = new ArrayList<>();
    Context context;

    public SeatAdapter(Context context) {
        this.context = context;
    }

    public ArrayList<SeatData> getList(){
        return this.listSeatData;
    }

    public void clearList(){
        this.listSeatData.clear();
    }
    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // return 인자는 ViewHolder 입니다.
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.seat_ltem, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ItemViewHolder holder, final int position) {
        // EventAdaper와 다른것은 holder final로 바꿨다.
        //listData : 현재 recyclerView로 가지고 있는 데이터 그릇을 의미
        //position : 현재 recyclerView의 position
        // Item을 하나, 하나 보여주는(bind 되는) 함수입니다.
        holder.onBind(listSeatData.get(position));

        holder.button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(holder.button1.getText().toString() =="X"){
                    holder.textView1.setText("");
                    holder.textView2.setText("");
                    holder.button1.setText("O");
                    Retrofit retrofit = new Retrofit.Builder().baseUrl("http://13.125.237.247:8000").addConverterFactory(GsonConverterFactory.create()).build();


                    RetroService retroservice = retrofit.create(RetroService.class);

                    Call<Void> call= retroservice.deleteBook(listSeatData.get(position).id);
                    Log.v("삭제번호",String.valueOf(listSeatData.get(position).id));
                    call.enqueue(new Callback<Void>(){
                        @Override
                        public void onResponse(Call<Void> call, Response<Void> response){
                            if(response.isSuccessful()){
                                Log.v("삭제알림","정상삭제");
                            }
                        }

                        @Override
                        public void onFailure(Call<Void> call, Throwable t){
                            Log.v("삭제실패알림","삭제실패");
                        }
                    });
                    listSeatData.remove(position);
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        // RecyclerView의 총 개수 입니다.
        if(listSeatData.isEmpty()){
            return 0;
        }
        return listSeatData.size();
    }


    void addItem(SeatData data) {
        // 외부에서 item을 추가시킬 함수입니다.
        listSeatData.add(data);
    }

    class ItemViewHolder extends RecyclerView.ViewHolder {

        private TextView textView1;
        private TextView textView2;
        private Button button1;


        ItemViewHolder(View itemView) {
            super(itemView);
            textView1 = (TextView) itemView.findViewById(R.id.Time);
            textView2 = (TextView) itemView.findViewById(R.id.UserId);
            button1 = (Button) itemView.findViewById(R.id.Seatbtn);


        }

        void onBind(final SeatData data) {
            textView1.setText("From " + data.getStartTime() + " to " + data.getFinishTime());
            textView2.setText(data.getUserId());

            if(data.getUserId()==""){button1.setText("O");}
            else {button1.setText("X");}

            button1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
        }
    }


}