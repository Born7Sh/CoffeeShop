package com.example.myapplication;

public class SeatData {
    int id;
    private String StartTime;
    private String FinishTime;
    private String UserId;
    public int sno;

    public SeatData(String StartTime, String FinishTime, String UserId) {
        this.StartTime = StartTime;
        this.FinishTime = FinishTime;
        this.UserId = UserId;
    }
    public SeatData(int id,String StartTime, String FinishTime, String UserId,int sno) {
        StartTime = StartTime.substring(StartTime.lastIndexOf("T")+1,StartTime.lastIndexOf("T")+6);
        FinishTime = FinishTime.substring(FinishTime.lastIndexOf("T")+1,FinishTime.lastIndexOf("T")+6);
        this.id=id;
        this.StartTime = StartTime;
        this.FinishTime = FinishTime;
        this.UserId = UserId;
        this.sno = sno;
    }
    public SeatData(int sno){
        this.StartTime ="비어있음";
        this.sno =sno;
    }
    public String getFinishTime() {
        return FinishTime;
    }

    public String getStartTime() {
        return StartTime;
    }

    public void setFinishTime(String finishTime) {
        FinishTime = finishTime;
    }

    public void setStartTime(String startTime) {
        StartTime = startTime;
    }

    public String getUserId() {
        return UserId;
    }

    public void setTime(boolean time,String t1){
        if(time){
            if(this.getStartTime().equals("비어있음")){
                this.setStartTime(t1);
            }
            this.setFinishTime(t1);
        }
    }

    public void setUserId(String userId) {
        UserId = userId;
    }
}
