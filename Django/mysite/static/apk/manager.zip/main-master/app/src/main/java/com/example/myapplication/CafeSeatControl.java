package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.WindowManager;

public class CafeSeatControl extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cafe_seat_control);

        // 예약최대시간은 Time
        // 자동로그인은 ON/OFF
        // 최대 좌석 수는 SeatNumber
        // 1인석 Seat1
        // 2인석 Seat2
        // 3인석 Seat3
        // 4인석 Seat4
    }

    protected void onPause(){
        super.onPause();
        overridePendingTransition(0, 0);
    }
}
