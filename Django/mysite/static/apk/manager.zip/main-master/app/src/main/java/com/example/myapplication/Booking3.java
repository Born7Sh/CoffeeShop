package com.example.myapplication;

import com.google.gson.annotations.SerializedName;


public class Booking3{

    @SerializedName("cno")
    int c_no;

    @SerializedName("sno")
    int s_no;

    boolean t1700;
    boolean t1730;
    boolean t1800;
    boolean t1830;
    boolean t1900;
    boolean t1930;
    boolean t2000;
    boolean t2030;
    boolean t2100;
    boolean t2130;
    boolean t2200;
    boolean t2230;
    boolean t2300;
    boolean t2330;
}