package com.example.myapplication;

import com.google.gson.annotations.SerializedName;

public class Booking2{

    @SerializedName("cno")
    int c_no;

    @SerializedName("sno")
    int s_no;

    boolean t0900;
    boolean t0930;
    boolean t1000;
    boolean t1030;
    boolean t1100;
    boolean t1130;
    boolean t1200;
    boolean t1230;
    boolean t1300;
    boolean t1330;
    boolean t1400;
    boolean t1430;
    boolean t1500;
    boolean t1530;
    boolean t1600;
    boolean t1630;

}
