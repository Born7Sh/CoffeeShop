package com.example.myapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class SeatControl extends AppCompatActivity {
    RecyclerView recyclerView2;
    // 데이터가 쌓이는 형태로 초기화 하고 싶으면  SeatAdapter adapter 전역변수로 설정하면 됨



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seat_control);

        //카페정보 객체 받아오기
        Intent intent = getIntent();
        final CafeInfo ci = (CafeInfo) intent.getSerializableExtra("CafeInfo");

        //새로고침
        final SwipeRefreshLayout Swipe = (SwipeRefreshLayout) findViewById(R.id.Swipe);

        Button SeatControl = (Button) findViewById(R.id.SeatAdminister);
        // 홈버튼은 Home
        Button Home = (Button) findViewById(R.id.Home);
        // 카페관리 버튼은 CafeAdminister
        Button CafeAdminister = (Button) findViewById(R.id.CafeAdminister);
        // 카페 현환 뷰는 SeatSituation
        final TextView SeatSituation = (TextView) findViewById(R.id.SeatSituation);

        //Seekbar은 Seekbar, 그걸 나타내는 숫자는 SeekbarNum
        final SeekBar Seekbar = (SeekBar) findViewById(R.id.SeekBar);
        final TextView SeekbarNum = (TextView) findViewById(R.id.SeekBarNum);


        //seatAdapter
        recyclerView2 = findViewById(R.id.SeatList);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView2.setLayoutManager(linearLayoutManager);

        final SeatAdapter adapter = new SeatAdapter(SeatControl.this);



        //서버에서 받아오기(Booking1)
    //    adapter =Booking1(adapter,ci);
      //  adapter = Booking2(adapter,ci);
        //adapter = Booking3(adapter,ci);
        /*
        //서버에서 받아오기 (Booking1)
        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://13.125.237.247:8000").addConverterFactory(GsonConverterFactory.create()).build();


        RetroService retroservice = retrofit.create(RetroService.class);

        Call<List<Booking1>> call = retroservice.getBook1();

        call.enqueue(new Callback<List<Booking1>>(){
            @Override
            public void onResponse(Call<List<Booking1>> call, Response<List<Booking1>> response){
                if(response.isSuccessful()){
                    Log.v("알림","성공");
                    List<Booking1> re1 = response.body();
                    ArrayList<SeatData> se1 = new ArrayList<>();
                    for(int i=0; i<re1.size(); i++){

                        if(re1.get(i).c_no == ci.no){

                            se1.add(new SeatData(re1.get(i).s_no));
                            se1.get(i).setTime(re1.get(i).t0000,"00:00");
                            se1.get(i).setTime(re1.get(i).t0030,"00:30");
                            se1.get(i).setTime(re1.get(i).t0100,"01:00");
                            se1.get(i).setTime(re1.get(i).t0130,"01:30");
                            se1.get(i).setTime(re1.get(i).t0200,"02:00");
                            se1.get(i).setTime(re1.get(i).t0230,"02:30");
                            se1.get(i).setTime(re1.get(i).t0300,"03:00");
                            se1.get(i).setTime(re1.get(i).t0330,"03:30");
                            se1.get(i).setTime(re1.get(i).t0400,"04:00");
                            se1.get(i).setTime(re1.get(i).t0430,"04:30");
                            se1.get(i).setTime(re1.get(i).t0500,"05:00");
                            se1.get(i).setTime(re1.get(i).t0530,"05:30");
                            se1.get(i).setTime(re1.get(i).t0600,"06:00");
                            se1.get(i).setTime(re1.get(i).t0630,"06:30");
                            se1.get(i).setTime(re1.get(i).t0700,"07:00");
                            se1.get(i).setTime(re1.get(i).t0730,"07:30");
                            se1.get(i).setTime(re1.get(i).t0800,"08:00");
                            se1.get(i).setTime(re1.get(i).t0830,"08:30");
                            se1.get(i).setUserId(String.valueOf(re1.get(i).s_no));
                            adapter.addItem(se1.get(i));
                            recyclerView2.setAdapter(adapter);
                        }
                    }
                }
            }
            @Override
            public void onFailure(Call<List<Booking1>> call, Throwable t){
                Log.v("알림","실패");
            }
        });

        //서버에서 받아오기(Booking2)
        Call<List<Booking2>> call2 = retroservice.getBook2();

        call2.enqueue(new Callback<List<Booking2>>(){
            @Override
            public void onResponse(Call<List<Booking2>> call, Response<List<Booking2>> response){
                if(response.isSuccessful()){
                    Log.v("알림","성공");
                    List<Booking2> re1 = response.body();
                    ArrayList<SeatData> se1 = new ArrayList<>();
                    for(int i=0; i<re1.size(); i++){

                        if(re1.get(i).c_no == ci.no){

                            se1.add(new SeatData(re1.get(i).s_no));
                            se1.get(i).setTime(re1.get(i).t0900,"09:00");
                            se1.get(i).setTime(re1.get(i).t0930,"09:30");
                            se1.get(i).setTime(re1.get(i).t1000,"10:00");
                            se1.get(i).setTime(re1.get(i).t1030,"10:30");
                            se1.get(i).setTime(re1.get(i).t1100,"11:00");
                            se1.get(i).setTime(re1.get(i).t1130,"11:30");
                            se1.get(i).setTime(re1.get(i).t1200,"12:00");
                            se1.get(i).setTime(re1.get(i).t1230,"12:30");
                            se1.get(i).setTime(re1.get(i).t1300,"13:00");
                            se1.get(i).setTime(re1.get(i).t1330,"13:30");
                            se1.get(i).setTime(re1.get(i).t1400,"14:00");
                            se1.get(i).setTime(re1.get(i).t1430,"14:30");
                            se1.get(i).setTime(re1.get(i).t1500,"15:00");
                            se1.get(i).setTime(re1.get(i).t1530,"15:30");
                            se1.get(i).setTime(re1.get(i).t1600,"16:00");
                            se1.get(i).setTime(re1.get(i).t1630,"16:30");
                            se1.get(i).setUserId(String.valueOf(re1.get(i).s_no));
                            adapter.addItem(se1.get(i));
                            recyclerView2.setAdapter(adapter);
                        }
                    }
                }
            }
            @Override
            public void onFailure(Call<List<Booking2>> call, Throwable t){
                Log.v("알림","실패");
            }
        });

        //서버에서 받아오기(Booking3)
        Call<List<Booking3>> call3 = retroservice.getBook3();

        call3.enqueue(new Callback<List<Booking3>>(){
            @Override
            public void onResponse(Call<List<Booking3>> call, Response<List<Booking3>> response){
                if(response.isSuccessful()){
                    Log.v("알림","성공");
                    List<Booking3> re1 = response.body();
                    ArrayList<SeatData> se1 = new ArrayList<>();
                    for(int i=0; i<re1.size(); i++){

                        if(re1.get(i).c_no == ci.no){

                            se1.add(new SeatData(re1.get(i).s_no));
                            se1.get(i).setTime(re1.get(i).t1700,"17:00");
                            se1.get(i).setTime(re1.get(i).t1730,"17:30");
                            se1.get(i).setTime(re1.get(i).t1800,"18:00");
                            se1.get(i).setTime(re1.get(i).t1830,"18:30");
                            se1.get(i).setTime(re1.get(i).t1900,"19:00");
                            se1.get(i).setTime(re1.get(i).t1930,"19:30");
                            se1.get(i).setTime(re1.get(i).t2000,"20:00");
                            se1.get(i).setTime(re1.get(i).t2030,"20:30");
                            se1.get(i).setTime(re1.get(i).t2100,"21:00");
                            se1.get(i).setTime(re1.get(i).t2130,"21:30");
                            se1.get(i).setTime(re1.get(i).t2200,"22:00");
                            se1.get(i).setTime(re1.get(i).t2230,"22:30");
                            se1.get(i).setTime(re1.get(i).t2300,"23:00");
                            se1.get(i).setTime(re1.get(i).t2330,"23:30");
                            se1.get(i).setUserId(String.valueOf(re1.get(i).s_no));
                            adapter.addItem(se1.get(i));
                            recyclerView2.setAdapter(adapter);

                        }
                    }
                }
            }
            @Override
            public void onFailure(Call<List<Booking3>> call, Throwable t){
                Log.v("알림","실패");
            }
        });
        */
        //진짜 서버에서 받아오기(check)
        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://13.125.237.247:8000").addConverterFactory(GsonConverterFactory.create()).build();


        RetroService retroservice = retrofit.create(RetroService.class);

        Call<List<Booking>> call = retroservice.getBook();

        call.enqueue(new Callback<List<Booking>>(){
            @Override
            public void onResponse(Call<List<Booking>> call, Response<List<Booking>> response){
                if(response.isSuccessful()){
                    Log.v("알림","성공");
                    List<Booking> re1 = response.body();
                    ArrayList<SeatData> se1 = new ArrayList<>();
                    ci.seat_curr=0;
                    for(int i=0; i<re1.size(); i++){

                        if(re1.get(i).cno == ci.no){

                            se1.add(new SeatData(re1.get(i).id,re1.get(i).start_time,re1.get(i).end_time,re1.get(i).uid,re1.get(i).sno));
                            ci.seat_curr++;
                            //se1.get(i).setUserId(String.valueOf(re1.get(i).s_no));
                            adapter.addItem(se1.get(i));
                            recyclerView2.setAdapter(adapter);
                        }
                    }
                }
            }
            @Override
            public void onFailure(Call<List<Booking>> call, Throwable t){
                Log.v("알림","실패");
            }
        });

        Log.v("숫자",String.valueOf(adapter.getItemCount()));

        // Maxseat 데이터베이스에서 받아올 최대 좌석수 변수
        int Maxseat = ci.seat_total;
        // TotalSeat 현재 페이지에서 조정 가능한 전체 좌석수 변수
        int TotalSeat = ci.seat_total -2;
        //  ReservedSeat 데이터베이스에서 받아올 현재 예약된 자리 변수

        Seekbar.setMax(Maxseat); // 데이터베이스에서 받아온 전체 좌석수 변수를 최대값으로 만듬
        Seekbar.setProgress(TotalSeat); // 현재 예약된 좌
        SeekbarNum.setText(String.valueOf(TotalSeat));
        //Seekbar.setMin(ReservedSeat); // 얘는 지금 예약된 자리보다 더 적어질수 없어야 하니깐 최소값 만들어준거



     //   SeatData data1 = new SeatData("12:30","14:30","asdasd");
     //   SeatData data2 = new SeatData("12:30","14:00","최강전설강혜효");

   //     adapter.addItem(data1);
     //   adapter.addItem(data2);

        recyclerView2.setAdapter(adapter);

        CafeAdminister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (v.getContext(), CafeAdminister.class);
                intent.putExtra("CafeInfo",ci);
                startActivity(intent);
            }
        });

        Home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (v.getContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        SeatControl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (v.getContext(), SeatControl.class);
                intent.putExtra("CafeInfo",ci);
                startActivity(intent);
            }
        });

        Swipe.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                // Execute code when refresh layout swiped
                adapter.clearList();
                //서버에서 받아오기 (Booking1)
                /*
                Retrofit retrofit = new Retrofit.Builder().baseUrl("http://13.125.237.247:8000").addConverterFactory(GsonConverterFactory.create()).build();


                RetroService retroservice = retrofit.create(RetroService.class);

                Call<List<Booking1>> call = retroservice.getBook1();

                call.enqueue(new Callback<List<Booking1>>(){
                    @Override
                    public void onResponse(Call<List<Booking1>> call, Response<List<Booking1>> response){
                        if(response.isSuccessful()){
                            Log.v("알림","성공");
                            List<Booking1> re1 = response.body();
                            ArrayList<SeatData> se1 = new ArrayList<>();
                            for(int i=0; i<re1.size(); i++){

                                if(re1.get(i).c_no == ci.no){

                                    se1.add(new SeatData(re1.get(i).s_no));
                                    se1.get(i).setTime(re1.get(i).t0000,"00:00");
                                    se1.get(i).setTime(re1.get(i).t0030,"00:30");
                                    se1.get(i).setTime(re1.get(i).t0100,"01:00");
                                    se1.get(i).setTime(re1.get(i).t0130,"01:30");
                                    se1.get(i).setTime(re1.get(i).t0200,"02:00");
                                    se1.get(i).setTime(re1.get(i).t0230,"02:30");
                                    se1.get(i).setTime(re1.get(i).t0300,"03:00");
                                    se1.get(i).setTime(re1.get(i).t0330,"03:30");
                                    se1.get(i).setTime(re1.get(i).t0400,"04:00");
                                    se1.get(i).setTime(re1.get(i).t0430,"04:30");
                                    se1.get(i).setTime(re1.get(i).t0500,"05:00");
                                    se1.get(i).setTime(re1.get(i).t0530,"05:30");
                                    se1.get(i).setTime(re1.get(i).t0600,"06:00");
                                    se1.get(i).setTime(re1.get(i).t0630,"06:30");
                                    se1.get(i).setTime(re1.get(i).t0700,"07:00");
                                    se1.get(i).setTime(re1.get(i).t0730,"07:30");
                                    se1.get(i).setTime(re1.get(i).t0800,"08:00");
                                    se1.get(i).setTime(re1.get(i).t0830,"08:30");
                                    se1.get(i).setUserId(String.valueOf(re1.get(i).s_no));
                                    adapter.addItem(se1.get(i));
                                    recyclerView2.setAdapter(adapter);
                                }
                            }
                        }
                    }
                    @Override
                    public void onFailure(Call<List<Booking1>> call, Throwable t){
                        Log.v("알림","실패");
                    }
                });

                //서버에서 받아오기(Booking2)
                Call<List<Booking2>> call2 = retroservice.getBook2();

                call2.enqueue(new Callback<List<Booking2>>(){
                    @Override
                    public void onResponse(Call<List<Booking2>> call, Response<List<Booking2>> response){
                        if(response.isSuccessful()){
                            Log.v("알림","성공");
                            List<Booking2> re1 = response.body();
                            ArrayList<SeatData> se1 = new ArrayList<>();
                            for(int i=0; i<re1.size(); i++){

                                if(re1.get(i).c_no == ci.no){

                                    se1.add(new SeatData(re1.get(i).s_no));
                                    se1.get(i).setTime(re1.get(i).t0900,"09:00");
                                    se1.get(i).setTime(re1.get(i).t0930,"09:30");
                                    se1.get(i).setTime(re1.get(i).t1000,"10:00");
                                    se1.get(i).setTime(re1.get(i).t1030,"10:30");
                                    se1.get(i).setTime(re1.get(i).t1100,"11:00");
                                    se1.get(i).setTime(re1.get(i).t1130,"11:30");
                                    se1.get(i).setTime(re1.get(i).t1200,"12:00");
                                    se1.get(i).setTime(re1.get(i).t1230,"12:30");
                                    se1.get(i).setTime(re1.get(i).t1300,"13:00");
                                    se1.get(i).setTime(re1.get(i).t1330,"13:30");
                                    se1.get(i).setTime(re1.get(i).t1400,"14:00");
                                    se1.get(i).setTime(re1.get(i).t1430,"14:30");
                                    se1.get(i).setTime(re1.get(i).t1500,"15:00");
                                    se1.get(i).setTime(re1.get(i).t1530,"15:30");
                                    se1.get(i).setTime(re1.get(i).t1600,"16:00");
                                    se1.get(i).setTime(re1.get(i).t1630,"16:30");
                                    se1.get(i).setUserId(String.valueOf(re1.get(i).s_no));
                                    adapter.addItem(se1.get(i));
                                    recyclerView2.setAdapter(adapter);
                                }
                            }
                        }
                    }
                    @Override
                    public void onFailure(Call<List<Booking2>> call, Throwable t){
                        Log.v("알림","실패");
                    }
                });

                //서버에서 받아오기(Booking3)
                Call<List<Booking3>> call3 = retroservice.getBook3();

                call3.enqueue(new Callback<List<Booking3>>(){
                    @Override
                    public void onResponse(Call<List<Booking3>> call, Response<List<Booking3>> response){
                        if(response.isSuccessful()){
                            Log.v("알림","성공");
                            List<Booking3> re1 = response.body();
                            ArrayList<SeatData> se1 = new ArrayList<>();
                            for(int i=0; i<re1.size(); i++){

                                if(re1.get(i).c_no == ci.no){

                                    se1.add(new SeatData(re1.get(i).s_no));
                                    se1.get(i).setTime(re1.get(i).t1700,"17:00");
                                    se1.get(i).setTime(re1.get(i).t1730,"17:30");
                                    se1.get(i).setTime(re1.get(i).t1800,"18:00");
                                    se1.get(i).setTime(re1.get(i).t1830,"18:30");
                                    se1.get(i).setTime(re1.get(i).t1900,"19:00");
                                    se1.get(i).setTime(re1.get(i).t1930,"19:30");
                                    se1.get(i).setTime(re1.get(i).t2000,"20:00");
                                    se1.get(i).setTime(re1.get(i).t2030,"20:30");
                                    se1.get(i).setTime(re1.get(i).t2100,"21:00");
                                    se1.get(i).setTime(re1.get(i).t2130,"21:30");
                                    se1.get(i).setTime(re1.get(i).t2200,"22:00");
                                    se1.get(i).setTime(re1.get(i).t2230,"22:30");
                                    se1.get(i).setTime(re1.get(i).t2300,"23:00");
                                    se1.get(i).setTime(re1.get(i).t2330,"23:30");
                                    se1.get(i).setUserId(String.valueOf(re1.get(i).s_no));
                                    adapter.addItem(se1.get(i));
                                    recyclerView2.setAdapter(adapter);
                                    Log.v("개수",String.valueOf(recyclerView2.getAdapter().getItemCount()));
                                }
                            }
                        }
                    }
                    @Override
                    public void onFailure(Call<List<Booking3>> call, Throwable t){
                        Log.v("알림","실패");
                    }
                });

                 */
                //check
                Retrofit retrofit = new Retrofit.Builder().baseUrl("http://13.125.237.247:8000").addConverterFactory(GsonConverterFactory.create()).build();


                RetroService retroservice = retrofit.create(RetroService.class);

                Call<List<Booking>> call = retroservice.getBook();

                call.enqueue(new Callback<List<Booking>>(){
                    @Override
                    public void onResponse(Call<List<Booking>> call, Response<List<Booking>> response){
                        if(response.isSuccessful()){
                            Log.v("알림","성공");
                            List<Booking> re1 = response.body();
                            ArrayList<SeatData> se1 = new ArrayList<>();
                            ci.seat_curr = 0;
                            for(int i=0; i<re1.size(); i++){
                                if(re1.get(i).cno == ci.no){
                                    se1.add(new SeatData(re1.get(i).id,re1.get(i).start_time,re1.get(i).end_time,re1.get(i).uid,re1.get(i).sno));
                                    ci.seat_curr++;
                                    //se1.get(i).setUserId(String.valueOf(re1.get(i).s_no));
                                    adapter.addItem(se1.get(i));
                                    recyclerView2.setAdapter(adapter);
                                }
                            }
                        }
                    }
                    @Override
                    public void onFailure(Call<List<Booking>> call, Throwable t){
                        Log.v("알림","실패");
                    }
                });


                Log.v("개수",String.valueOf(recyclerView2.getAdapter().getItemCount()));
                Swipe.setRefreshing(false);
            }
        });

        Seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onStopTrackingTouch(SeekBar seekBar) {
                //멈췄을 때 이미 예약된 자리보다 자리가 적어지면 안됨

                SeekbarNum.setText(String.valueOf(seekBar.getProgress())); // 표옆에 숫자 업데이트
                String string = String.valueOf(recyclerView2.getAdapter().getItemCount()) + "/" + String.valueOf(seekBar.getProgress());
                SeatSituation.setText(string); // 현황 업데이트
                ci.seat_total=seekBar.getProgress();
                ci.changeInfo();
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
               SeekbarNum.setText(String.valueOf(seekBar.getProgress()));
                String string = String.valueOf(recyclerView2.getAdapter().getItemCount()) + "/" + String.valueOf(seekBar.getProgress());
                SeatSituation.setText(string);
            }

            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {
                if(progress < recyclerView2.getAdapter().getItemCount()) {
                    Toast myToast = Toast.makeText(getApplicationContext(),"좌석은 예약자 보다 적을 수 없습니다.", Toast.LENGTH_SHORT);
                    myToast.show();
                    seekBar.setProgress(recyclerView2.getAdapter().getItemCount());
                }
                SeekbarNum.setText(String.valueOf(progress));
                String string = String.valueOf(recyclerView2.getAdapter().getItemCount()) + "/" + String.valueOf(progress);
                SeatSituation.setText(string);
            }
        });



    }

    protected void onPause(){
        super.onPause();
        overridePendingTransition(0, 0);
    }

    private SeatAdapter Booking1(final SeatAdapter adapter, final CafeInfo ci){
        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://13.125.237.247:8000").addConverterFactory(GsonConverterFactory.create()).build();


        RetroService retroservice = retrofit.create(RetroService.class);

        Call<List<Booking1>> call = retroservice.getBook1();

        call.enqueue(new Callback<List<Booking1>>(){
            @Override
            public void onResponse(Call<List<Booking1>> call, Response<List<Booking1>> response){
                if(response.isSuccessful()){
                    Log.v("알림","성공");
                    List<Booking1> re1 = response.body();
                    ArrayList<SeatData> se1 = new ArrayList<>();
                    for(int i=0; i<re1.size(); i++){

                        if(re1.get(i).c_no == ci.no){
                            /* 이건 나중에 사용자에서 한번에 예약하려고하면수정할것(지금은 시간대를 나눠서 예약)
                           for(int j=0; j<adapter.getItemCount(); i++){
                                if(adapter.getList().get(j).sno==re1.get(i).s_no){
                                    //원래 예약에 더해주기
                                }
                            }

                        }*/
                            se1.add(new SeatData(re1.get(i).s_no));
                            se1.get(i).setTime(re1.get(i).t0000,"00:00");
                            se1.get(i).setTime(re1.get(i).t0030,"00:30");
                            se1.get(i).setTime(re1.get(i).t0100,"01:00");
                            se1.get(i).setTime(re1.get(i).t0130,"01:30");
                            se1.get(i).setTime(re1.get(i).t0200,"02:00");
                            se1.get(i).setTime(re1.get(i).t0230,"02:30");
                            se1.get(i).setTime(re1.get(i).t0300,"03:00");
                            se1.get(i).setTime(re1.get(i).t0330,"03:30");
                            se1.get(i).setTime(re1.get(i).t0400,"04:00");
                            se1.get(i).setTime(re1.get(i).t0430,"04:30");
                            se1.get(i).setTime(re1.get(i).t0500,"05:00");
                            se1.get(i).setTime(re1.get(i).t0530,"05:30");
                            se1.get(i).setTime(re1.get(i).t0600,"06:00");
                            se1.get(i).setTime(re1.get(i).t0630,"06:30");
                            se1.get(i).setTime(re1.get(i).t0700,"07:00");
                            se1.get(i).setTime(re1.get(i).t0730,"07:30");
                            se1.get(i).setTime(re1.get(i).t0800,"08:00");
                            se1.get(i).setTime(re1.get(i).t0830,"08:30");
                            se1.get(i).setUserId(String.valueOf(re1.get(i).s_no));
                            adapter.addItem(se1.get(i));
                        }
                    }
                }
            }
            @Override
            public void onFailure(Call<List<Booking1>> call, Throwable t){
                Log.v("알림","실패");
            }
        });
        return adapter;
    }

    private SeatAdapter Booking2(final SeatAdapter adapter, final CafeInfo ci){
        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://13.125.237.247:8000").addConverterFactory(GsonConverterFactory.create()).build();


        RetroService retroservice = retrofit.create(RetroService.class);

        Call<List<Booking2>> call = retroservice.getBook2();

        call.enqueue(new Callback<List<Booking2>>(){
            @Override
            public void onResponse(Call<List<Booking2>> call, Response<List<Booking2>> response){
                if(response.isSuccessful()){
                    Log.v("알림","성공");
                    List<Booking2> re1 = response.body();
                    ArrayList<SeatData> se1 = new ArrayList<>();
                    for(int i=0; i<re1.size(); i++){

                        if(re1.get(i).c_no == ci.no){
                            /* 이건 나중에 사용자에서 한번에 예약하려고하면수정할것(지금은 시간대를 나눠서 예약)
                           for(int j=0; j<adapter.getItemCount(); i++){
                                if(adapter.getList().get(j).sno==re1.get(i).s_no){
                                    //원래 예약에 더해주기
                                }
                            }

                        }*/
                            se1.add(new SeatData(re1.get(i).s_no));
                            se1.get(i).setTime(re1.get(i).t0900,"09:00");
                            se1.get(i).setTime(re1.get(i).t0930,"09:30");
                            se1.get(i).setTime(re1.get(i).t1000,"10:00");
                            se1.get(i).setTime(re1.get(i).t1030,"10:30");
                            se1.get(i).setTime(re1.get(i).t1100,"11:00");
                            se1.get(i).setTime(re1.get(i).t1130,"11:30");
                            se1.get(i).setTime(re1.get(i).t1200,"12:00");
                            se1.get(i).setTime(re1.get(i).t1230,"12:30");
                            se1.get(i).setTime(re1.get(i).t1300,"13:00");
                            se1.get(i).setTime(re1.get(i).t1330,"13:30");
                            se1.get(i).setTime(re1.get(i).t1400,"14:00");
                            se1.get(i).setTime(re1.get(i).t1430,"14:30");
                            se1.get(i).setTime(re1.get(i).t1500,"15:00");
                            se1.get(i).setTime(re1.get(i).t1530,"15:30");
                            se1.get(i).setTime(re1.get(i).t1600,"16:00");
                            se1.get(i).setTime(re1.get(i).t1630,"16:30");
                            se1.get(i).setUserId(String.valueOf(re1.get(i).s_no));
                            adapter.addItem(se1.get(i));

                        }
                    }
                }
            }
            @Override
            public void onFailure(Call<List<Booking2>> call, Throwable t){
                Log.v("알림","실패");
            }
        });
        return adapter;
    }

    private SeatAdapter Booking3(final SeatAdapter adapter, final CafeInfo ci){
        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://13.125.237.247:8000").addConverterFactory(GsonConverterFactory.create()).build();


        RetroService retroservice = retrofit.create(RetroService.class);

        Call<List<Booking3>> call = retroservice.getBook3();

        call.enqueue(new Callback<List<Booking3>>(){
            @Override
            public void onResponse(Call<List<Booking3>> call, Response<List<Booking3>> response){
                if(response.isSuccessful()){
                    Log.v("알림","성공");
                    List<Booking3> re1 = response.body();
                    ArrayList<SeatData> se1 = new ArrayList<>();
                    for(int i=0; i<re1.size(); i++){

                        if(re1.get(i).c_no == ci.no){
                            /* 이건 나중에 사용자에서 한번에 예약하려고하면수정할것(지금은 시간대를 나눠서 예약)
                           for(int j=0; j<adapter.getItemCount(); i++){
                                if(adapter.getList().get(j).sno==re1.get(i).s_no){
                                    //원래 예약에 더해주기
                                }
                            }

                        }*/
                            se1.add(new SeatData(re1.get(i).s_no));
                            se1.get(i).setTime(re1.get(i).t1700,"17:00");
                            se1.get(i).setTime(re1.get(i).t1730,"17:30");
                            se1.get(i).setTime(re1.get(i).t1800,"18:00");
                            se1.get(i).setTime(re1.get(i).t1830,"18:30");
                            se1.get(i).setTime(re1.get(i).t1900,"19:00");
                            se1.get(i).setTime(re1.get(i).t1930,"19:30");
                            se1.get(i).setTime(re1.get(i).t2000,"20:00");
                            se1.get(i).setTime(re1.get(i).t2030,"20:30");
                            se1.get(i).setTime(re1.get(i).t2100,"21:00");
                            se1.get(i).setTime(re1.get(i).t2130,"21:30");
                            se1.get(i).setTime(re1.get(i).t2200,"22:00");
                            se1.get(i).setTime(re1.get(i).t2230,"22:30");
                            se1.get(i).setTime(re1.get(i).t2300,"23:00");
                            se1.get(i).setTime(re1.get(i).t2330,"23:30");
                            se1.get(i).setUserId(String.valueOf(re1.get(i).s_no));
                            adapter.addItem(se1.get(i));
                        }
                    }
                }
            }
            @Override
            public void onFailure(Call<List<Booking3>> call, Throwable t){
                Log.v("알림","실패");
            }
        });
        return adapter;
    }


}
