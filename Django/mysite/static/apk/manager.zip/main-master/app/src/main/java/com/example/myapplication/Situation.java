package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Situation extends AppCompatActivity {

    //sdsdsdsdsdsdsdsdsdsdasdsa
    RecyclerView recyclerView;
    EventAdapter adapter;
    String heelo;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);

        Intent intent =getIntent();

        final CafeInfo ci = (CafeInfo)intent.getSerializableExtra("CafeInfo");

        setContentView(R.layout.activity_situation);
        // x 이미지 Cancel
        ImageView Cancel = (ImageView) findViewById(R.id.Cancel);
        // 선택삭제 버튼 Delete

        Cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        recyclerView = findViewById(R.id.EventList);

        //inearLayoutManager.HORIZONTAL로 넘기는 방향설정 가능 (첫번쨰파라미터는 context 세번쨰파라미터는 아이템이 보이는 방향을 애기한다.)
        //세번쨰파라미터는 예를들어 채팅방같은 경우 메세지가 아래에서 위로 올라가는 방향같은거 설정
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false); //레이아웃매니저 생성

        recyclerView.setLayoutManager(layoutManager);//만든 레이아웃매니저 객체를(설정을) 리사이클러 뷰에 설정해줌

        adapter = new EventAdapter(getApplicationContext());
        //아이템추가

        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://13.125.237.247:8000").addConverterFactory(GsonConverterFactory.create()).build();


        RetroService retroservice = retrofit.create(RetroService.class);

        Call<List<Time_sale>> call = retroservice.getTimeSale(2);

        call.enqueue(new Callback<List<Time_sale>>(){
            @Override
            public void onResponse(Call<List<Time_sale>> call, Response<List<Time_sale>> response){
                if(response.isSuccessful()){
                    Log.v("알림","성공");
                    List<Time_sale> re1 = response.body();

                    for(int i=0; i<re1.size(); i++){
                        if(re1.get(i).cno == ci.no){
                            adapter.addItem(new EventData(re1.get(i).name,String.valueOf(re1.get(i).rprice),String.valueOf(re1.get(i).sprice)));
                            recyclerView.setAdapter(adapter);
                            Log.v("알림",re1.get(i).name);
                        }
                    }
                }
            }
            @Override
            public void onFailure(Call<List<Time_sale>> call, Throwable t){
                Log.v("알림","실패");
            }
        });




        //어댑터에 연결

    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        //바깥레이어 클릭시 안닫히게
        if(event.getAction()==MotionEvent.ACTION_OUTSIDE){
            return false;
        }
        return true;
    }

}


