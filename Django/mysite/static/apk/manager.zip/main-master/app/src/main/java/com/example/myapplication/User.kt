package com.example.myapplication

data class User(
        var name: String,
        var id : String,
        var email: String,
        var sex: String,
        var phone: String,
        var birthday: String
)