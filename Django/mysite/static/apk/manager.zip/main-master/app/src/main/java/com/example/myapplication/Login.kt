package com.example.myapplication

data class Login(
    val code: String,
    val msg: String
)

