package com.example.myapplication;

import android.text.Editable;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class CafeInfo implements Serializable {
    @SerializedName("id")
    int no;
    //카페이름
    @SerializedName("cafe_name")
    String cafe_name;
    //사용자이름
    String user_name;
    //위치정보
    @SerializedName("x")
    float positionX;
    @SerializedName("y")
    float positionY;
    //영업시간

    String start_time;

    String end_time;
    //금일 영업 시간
    String start_today;
    String end_today;
    //전화번호
    @SerializedName("phone")
    String call_num;
    //email
    @SerializedName("com_num")
    String email;
    //전체 좌석 수
    @SerializedName("seat_total")
    int seat_total;
    //현재 좌석 수
    @SerializedName("seat_curr")
    int seat_curr;
    //카페 소개
    @SerializedName("notice")
    String cafe_intro;
    //현재 영업 상태
    @SerializedName("business")
    boolean op_cl;

    @SerializedName("star")
    float star;

    @SerializedName("event")
    String event;

    /*
        서버에서 카페 정보 받아오기
     */
    public void cafeCurrent(String userid, final CafeInfo ci) {
        this.cafe_name = "14gramCafe";
        this.no=1;
       /* this.positionX = 11;
        this.positionY=12;
        this.user_name = "최김장황";
        this.start_time = "15:00:00";
        this.end_time = "17:00:00";
        this.seat_total = 10;
        this.seat_curr = 2;
        this.op_cl = true;
        this.event = "123";
        this.star = 4;
        this.call_num = "12";
        this.email = "123";
        this.no = 2;
        this.cafe_intro = "안녕하세요";

        */
    }

    public void getCafeInfo(final CafeInfo ci){
        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://13.125.237.247:8000").addConverterFactory(GsonConverterFactory.create()).build();


        RetroService retroservice = retrofit.create(RetroService.class);

  /*      Call<List<ComCafeInfo>> call = retroservice.requestCafe(2);

        call.enqueue(new Callback<List<ComCafeInfo>>(){
            @Override
            public void onResponse(Call<List<ComCafeInfo>> call, Response<List<ComCafeInfo>> response){
                if(response.isSuccessful()){
                    Log.v("알림","성공");
                    List<ComCafeInfo> re1 = response.body();
                    Log.v("알림", re1.get(0).cafe_name);
                    Log.v("알림", re1.get(0).cafe_intro);
                    Log.v("알림", re1.get(0).start_time);
                    ci.cafe_name = re1.get(0).cafe_name;
                    ci.positionX = re1.get(0).positionX;
                    ci.positionY = re1.get(0).positionY;
                    ci.start_time = re1.get(0).start_time;
                    ci.end_time = re1.get(0).end_time;
                    ci.call_num = re1.get(0).call_num;
                    ci.cafe_intro = re1.get(0).cafe_intro;
                    ci.star = re1.get(0).star;
                    ci.email = re1.get(0).email;
                    ci.op_cl = re1.get(0).op_cl;
                    ci.seat_total = re1.get(0).seat_total;

                }
            }
            @Override
            public void onFailure(Call<List<ComCafeInfo>> call, Throwable t){
                Log.v("알림","실패");
            }
    });


   */

        Map map = new HashMap();
        map.put("search",this.cafe_name);

        Call<ComCafeInfo> call = retroservice.requestCafe(this.no);

        call.enqueue(new Callback<ComCafeInfo>(){
            @Override
            public void onResponse(Call<ComCafeInfo> call, Response<ComCafeInfo> response){
                if(response.isSuccessful()){
                    Log.v("알림","성공");
                    ComCafeInfo re1 = response.body();
                    Log.v("알림", re1.cafe_name);
                    Log.v("알림", re1.cafe_intro);
                    Log.v("알림", re1.start_time);
                    ci.cafe_name = re1.cafe_name;
                    ci.positionX = re1.positionX;
                    ci.positionY = re1.positionY;
                    ci.start_time = re1.start_time;
                    ci.end_time = re1.end_time;
                    ci.call_num = re1.call_num;
                    ci.cafe_intro = re1.cafe_intro;
                    ci.star = re1.star;
                    ci.email = re1.email;
                    ci.op_cl = re1.op_cl;
                    ci.seat_curr= re1.seat_curr;
                    ci.seat_total = re1.seat_total;
                    Log.v("성공","성공");
                }
            }
            @Override
            public void onFailure(Call<ComCafeInfo> call, Throwable t){
                Log.v("알림","실패");
            }
        });
    }

    /*
        변경 클릭하고 변경 시 서버에 변경 정보 보내기
     */
    public void changeInfo() {
        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://13.125.237.247:8000").addConverterFactory(GsonConverterFactory.create()).build();

        RetroService retroservice = retrofit.create(RetroService.class);

        Call<ComCafeInfo> call = retroservice.putCafe(1,"json", this.cafe_name,this.positionX,this.positionY,this.start_time,this.end_time,
                this.call_num,this.cafe_intro,this.star,this.email,this.op_cl,this.seat_total,this.seat_curr);


                    call.enqueue(new Callback<ComCafeInfo>(){
                        @Override
                        public void onResponse(Call<ComCafeInfo> call, Response<ComCafeInfo> response){
                            if(response.isSuccessful()){
                    Log.v("알림","성공");
                }
            }

            @Override
            public void onFailure(Call<ComCafeInfo> call, Throwable t){
                    Log.v("알림","실패");
            }
        });

    }

    public void provideInfo(){
        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://13.125.237.247:8000").addConverterFactory(GsonConverterFactory.create()).build();

        RetroService retroservice = retrofit.create(RetroService.class);

        Call<ComCafeInfo> call = retroservice.provideCafe("json",this.cafe_name,this.positionX,this.positionY,this.start_time,this.end_time,
                this.call_num,this.cafe_intro,this.star,this.email,true,this.seat_total,this.seat_curr);


        call.enqueue(new Callback<ComCafeInfo>(){
            @Override
            public void onResponse(Call<ComCafeInfo> call, Response<ComCafeInfo> response){
                if(response.isSuccessful()){
                    Log.v("알림","성공");
                }
            }

            @Override
            public void onFailure(Call<ComCafeInfo> call, Throwable t){
                Log.v("알림","실패");
            }
        });

    }
    /*
        카페 소개 문구 변경
     */
    public void changeIntro(Editable textinfo) {
        this.cafe_intro = String.valueOf(textinfo);
        this.changeInfo();
    }

    /*
        좌석 변경이 있을 시
     */
    public void changeSeat() {

    }

    /*리뷰

     */
    public void requestReview(){
        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://13.125.237.247:8000").addConverterFactory(GsonConverterFactory.create()).build();

        RetroService retroservice = retrofit.create(RetroService.class);

        Call<List<Review>> call = retroservice.requestReview("json","장호민");

        call.enqueue(new Callback<List<Review>>(){
            @Override
            public void onResponse(Call<List<Review>> call, Response<List<Review>> response){
                if(response.isSuccessful()){
                    Log.v("알림","성공");
                    List<Review> re1 = response.body();

                    Log.v("알림", re1.get(0).uid);
                    Log.v("알림", re1.get(0).review);
                }
            }

            @Override
            public void onFailure(Call<List<Review>> call, Throwable t){
                Log.v("알림","실패");
            }
        });
    }
    public void makeReview(){
        Review re1 = new Review();
        re1.uid = "안녕함qweqwe";
        re1.review = "하이qweqweqwe";

        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://13.125.237.247:8000").addConverterFactory(GsonConverterFactory.create()).build();

        RetroService retroservice = retrofit.create(RetroService.class);

        Call<Review> call = retroservice.provideReview("json",re1.uid,re1.review);
        //retroservice.provideReview(re1.uid,re1.review).enqueue(new Callback<Review>()
                //
        call.enqueue(new Callback<Review>(){
            @Override
            public void onResponse(Call<Review> call, Response<Review> response){
                if(response.isSuccessful()){
                    Log.v("알림","성공");
                }
            }

            @Override
            public void onFailure(Call<Review> call, Throwable t){
                    Log.v("알림","실패");
            }
        });

    }

    public void makeTimeSale(Time_sale t1){


        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://13.125.237.247:8000").addConverterFactory(GsonConverterFactory.create()).build();

        RetroService retroservice = retrofit.create(RetroService.class);

        Call<Time_sale> call = retroservice.provideTimeSale("json",t1.name,t1.cno,t1.rprice,t1.sprice);

        call.enqueue(new Callback<Time_sale>(){
            @Override
            public void onResponse(Call<Time_sale> call, Response<Time_sale> response){
                if(response.isSuccessful()){
                    Log.v("알림","성공");
                }
            }

            @Override
            public void onFailure(Call<Time_sale> call, Throwable t){
                Log.v("알림","실패");

            }
        });
    }

    /*
        홈에서 Open,Close 클릭(영업 시작과 종료)
     */
    public void cafeOpCl(Button opcl) {

        /*
            영업 종료
            opcl은 영업중인지 확인하는 시그널->0이면 영업종료
         */
        if (opcl.getText().equals("OPEN")) {
            /*
                현재시간 구하기
             */
            long curtime = System.currentTimeMillis();
            Date date = new Date(curtime);
            SimpleDateFormat send = new SimpleDateFormat("hh:mm:ss");


            opcl.setText("CLOSE");
            this.op_cl = false;
        }
        /*
            영업 시작
         */
        else if (opcl.getText().equals("CLOSE")) {
            /*
                현재시간 구하기
             */
            long curtime = System.currentTimeMillis();
            Date date = new Date(curtime);
            SimpleDateFormat sstart = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
           // start_time = LocalTime.now();

            opcl.setText("OPEN");
            this.op_cl = true;

        }
    }

    public void setMainText(TextView cA, TextView seat, TextView st, TextView et) {
        if (this.op_cl == true) {
            cA.setText("영업중");
        } else if (this.op_cl == false) {
            cA.setText("영업종료");
        }
        seat.setText(String.valueOf(this.seat_curr) + "/" + String.valueOf(this.seat_total));

        st.setText(this.start_today);
        et.setText(this.end_today);
    }

    /*
        영업상태 변경(메인화면)
     */
    public String getActiveText() {
        if (this.op_cl == true) {
            return "영업중";
        } else if (this.op_cl == false) {
            return "영업종료";
        }
        return "";
    }




}

