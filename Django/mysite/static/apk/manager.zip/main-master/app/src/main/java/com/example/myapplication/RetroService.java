package com.example.myapplication;

import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.http.DELETE;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;

public interface RetroService {
    @GET("/cafe/{path}/")
    Call<ComCafeInfo> requestCafe(@Path("path") int id);

    @FormUrlEncoded
    @POST("/cafe/")
    Call<ComCafeInfo> provideCafe(
            @Query("format") String json,
            @Field("cafe_name") String cafe_name,
            @Field("x") float x,
            @Field("y") float y,
            @Field("start_time") String start_time,
            @Field("end_time") String end_time,
            @Field("phone") String phone,
            @Field("notice") String notice,
            @Field("star") float star,
            @Field("com_num") String com_num,
            @Field("business") boolean business,
            @Field("seat_total") int seat_total,
            @Field("seat_curr") int seat_curr);

    @FormUrlEncoded
    @POST("/review/")
            Call<Review> provideReview(
                    @Query("format") String json,
            @Field("uid") String uid,
            @Field("review") String review
            );

    @GET("/review/")
    Call<List<Review>> requestReview(@Query("format") String json,@Query("uid") String uid);

    @FormUrlEncoded
    @POST("/timesale/")
    Call<Time_sale> provideTimeSale(
            @Query("format") String json,
            @Field("name") String name,
            @Field("cno") int cno,
            @Field("rprice") int rprice,
            @Field("sprice") int sprice
    );

    @FormUrlEncoded
    @PUT("/cafe/{id}/")
    Call<ComCafeInfo> putCafe( @Path("id") int id,
                           @Query("format") String json,
                           @Field("cafe_name") String cafe_name,
                           @Field("x") float x,
                           @Field("y") float y,
                           @Field("start_time") String start_time,
                           @Field("end_time") String end_time,
                           @Field("phone") String phone,
                           @Field("notice") String notice,
                           @Field("star") double star,
                           @Field("com_num") String com_num,
                           @Field("business") boolean business,
                           @Field("seat_total") int seat_total,
                           @Field("seat_curr") int seat_curr
    );

    @GET("/timesale")
    Call<List<Time_sale>> getTimeSale(
            @Query("cno") int cno
    );



    @PUT("/time_sale")
    Call<List<Time_sale>> requestTimeSale(@Path("c_no") int c_no);

    @GET("/booking1")
    Call<List<Booking1>> getBook1();

    @GET("/booking2")
    Call<List<Booking2>> getBook2();

    @GET("/booking3")
    Call<List<Booking3>> getBook3();

    @GET("/check")
    Call<List<Booking>> getBook();

    @DELETE("/check/{id}")
    Call<Void> deleteBook(@Path("id")int id);
}
