package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.jetbrains.annotations.NonNls;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        final CafeInfo ci = new CafeInfo();
        ci.cafeCurrent("123",ci);
        ci.getCafeInfo(ci);

        /*
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://13.125.237.247:8000")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        RetroService retroservice = retrofit.create(RetroService.class);

        retroservice.requestCafe("userid").enqueue(new Callback<CafeInfo>(){
            @Override
            public void onResponse(@NonNull Call<CafeInfo> call, @NonNull Response<CafeInfo> response){
                if(response.isSuccessful()){
                    CafeInfo data = response.body();

                }
            }

            @Override
            public void onFailure(Call<CafeInfo> call, Throwable t){

            }
        });
        */
        // 위에 뜨는 카페이름은 CafeName
        // 그 밑에 뜨는 아이디는 Name

        // 개인 설정하러가는 꺾쇠는 UserInfo
        LinearLayout UserInfo = (LinearLayout) findViewById(R.id.UserInfo);
        // 설정은 Setting
        ImageView Setting = (ImageView) findViewById(R.id.Setting);

        // 전체 창은 information
        final LinearLayout information = (LinearLayout) findViewById(R.id.Information);

        // 카페 활성화/비활성화는 Active
        final TextView TextActive = (TextView)findViewById(R.id.Active);
        // 카페 좌석은 Seat
        final TextView TextSeat = (TextView)findViewById(R.id.Seat);

        // 카페 영업 시작 시간은 StartTime
        final TextView TextST = (TextView)findViewById(R.id.StartTime);
        // 카페 영업 종료 시간은 CloseTime
        final TextView TextCL = (TextView)findViewById(R.id.CloseTime);
        // CLOSE 버튼 Close

        final Button ButtonCL = (Button)findViewById(R.id.Close);
                ButtonCL.setOnClickListener(new View.OnClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onClick(View v) {
                        ci.cafeOpCl(ButtonCL);
                       // ci.provideInfo();
                        ci.changeInfo();
                        TextActive.setText(ci.getActiveText());
            }
    });



        // 새로고침 버튼 Refresh
        final ImageView Refresh = (ImageView) findViewById( (R.id.Refresh));

        // 좌석 관리 버튼은 SeatAdminister
        Button SeatControl = (Button) findViewById(R.id.SeatAdminister);
        // 홈버튼은 Home
        Button Home = (Button) findViewById(R.id.Home);
        // 카페관리 버튼은 CafeAdminister
        Button CafeAdminister = (Button) findViewById(R.id.CafeAdminister);

        ci.setMainText(TextActive,TextSeat,TextST,TextCL);

        UserInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (v.getContext(), UserInformation.class);
                ci.getCafeInfo(ci);
                intent.putExtra("CafeInfo", ci);
                intent.addFlags (Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
            }
        });

        Setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (v.getContext(), Setting.class);
                ci.getCafeInfo(ci);
                intent.addFlags (Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
            }
        });

        CafeAdminister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (v.getContext(), CafeAdminister.class);
                ci.getCafeInfo(ci);
                intent.putExtra("CafeInfo", ci);
                intent.addFlags (Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
            }
        });

        SeatControl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (v.getContext(), SeatControl.class);
                intent.putExtra("CafeInfo", ci);
                intent.addFlags (Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
            }
        });

        //
        Refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                information.invalidate();
                //ci.changeInfo();
                ci.getCafeInfo(ci);
                TextST.setText(ci.start_time);
                // 카페 영업 종료 시간은 CloseTime
                TextCL.setText(ci.end_time);
                TextActive.setText(ci.getActiveText());
                TextSeat.setText(String.valueOf(ci.seat_curr) + "/" + String.valueOf(ci.seat_total));
               // TextActive.setText(ci.getActiveText());
            }
        });

    }
}
