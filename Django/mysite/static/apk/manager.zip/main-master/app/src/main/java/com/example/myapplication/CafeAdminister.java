package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class CafeAdminister extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cafe_administer);

        Intent intent = getIntent();

        final CafeInfo ci = (CafeInfo)intent.getSerializableExtra("CafeInfo");

        // 첫번째 EditText는 Info
        final EditText Info = (EditText)findViewById(R.id.Info);
        Info.setText(ci.cafe_intro);
        // 첫번째 버튼은 Register1
        Button Register1 = (Button)findViewById(R.id.Register1);
        Register1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               ci.cafe_intro = String.valueOf(Info.getText());
               ci.changeInfo();
            }
        });
        // 품목명 EditText는 SaleProduct
        final EditText SaleProduct = (EditText)findViewById(R.id.SaleProduct);
        // 가격 전자는 Price1 후자는 Price2
        final EditText Price1 = (EditText)findViewById(R.id.Price1);
        final EditText Price2 = (EditText)findViewById(R.id.Price2);
        // 현황 버튼은 Register2
        Button Situation = (Button) findViewById(R.id.Register2);
        // 등록 버튼은 Register3
        Button Register3 = (Button)findViewById(R.id.Register3);
        Register3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Time_sale t1 = new Time_sale();
                t1.name = String.valueOf(SaleProduct.getText());
                t1.cno = ci.no;
                t1.rprice = Integer.parseInt(String.valueOf(Price1.getText()));
                t1.sprice = Integer.parseInt(String.valueOf(Price2.getText()));
                ci.makeTimeSale(t1);
            }
        });

        Button Home = (Button) findViewById(R.id.Home);
        Button CafeAdminister = (Button) findViewById(R.id.CafeAdminister);

        Home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Situation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (v.getContext(), Situation.class);
                intent.putExtra("CafeInfo",ci);
                startActivity(intent);
            }
        });

        CafeAdminister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (v.getContext(), CafeAdminister.class);
                startActivity(intent);
            }
        });

    }
}
