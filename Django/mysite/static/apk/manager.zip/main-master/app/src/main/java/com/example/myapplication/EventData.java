package com.example.myapplication;

public class EventData {
    private String EventProduct;
    private String price1;
    private String price2;

    public EventData(String eventProduct, String price1, String price2) {
        this.EventProduct = eventProduct;;
        this.price1 = price1;
        this.price2 = price2;
    }

    public void setEventProduct(String eventProduct) {
        EventProduct = eventProduct;
    }

    public void setPrice1(String price1) {
        this.price1 = price1;
    }

    public void setPrice2(String price2) {
        this.price2 = price2;
    }

    public String getPrice1() {
        return this.price1;
    }

    public String getPrice2() {
        return this.price2;
    }

    public String getEventProduct() {
        return this.EventProduct;
    }
}
