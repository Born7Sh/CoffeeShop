package com.example.myapplication;

import com.google.gson.annotations.SerializedName;

public class Time_sale {

    String name;
    @SerializedName("cno")
    int cno;
    @SerializedName("rprice")
    int rprice;
    @SerializedName("sprice")
    int sprice;

    public void getName(String name){
        this.name = name;
    }
    public void getRPrice(int price){
        this.rprice = price;
    }
    public void getSPrice(int price){
        this.sprice = price;
    }
}
